FONT_DEFINE(coins)
FONT_DEFINE(level_end)
